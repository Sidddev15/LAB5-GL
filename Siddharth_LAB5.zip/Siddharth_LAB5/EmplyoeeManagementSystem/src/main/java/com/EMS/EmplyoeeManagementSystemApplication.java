package com.EMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmplyoeeManagementSystemApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(EmplyoeeManagementSystemApplication.class, args);
		
		System.out.println("Welcome to Employee Management System");
	}

}
